import mysql.connector
from oliot import Tiketti
from oliot import Tyontekija
from contextlib import closing


palvelin = "localhost"
tietokanta = "helpdeskpiispa"
tunnus = "root"
salasana = ""


muntk = None

def connect():
    global muntk
    if not muntk:
        muntk = mysql.connector.connect(host=palvelin, database=tietokanta, user=tunnus, password=salasana,)
        muntk.row_factory = mysql.connector.ROWID
        #print("yhteys avattu")
        
def close():
    if muntk:
        muntk.close()
        #print("yhteys lopetettu")
        
def luo_tiketti(rivi):
    return Tiketti(rivi["tikettiID"], rivi["statusID"], rivi["ratkaisuID"], rivi["tyontekijaID"], rivi["asia"], rivi["asiakasnimi"], rivi["asiakassposti"], rivi["nimi"], rivi["status"], rivi["ratkaisu"], rivi["kirjauspaiva"])
     
def luo_tyontekija(rivi):
    return Tyontekija(rivi["tyontekijaID"], rivi["nimi"], rivi["tunnus"], rivi["salasana"], rivi["sposti"], rivi["rooliID"], rivi["rooli"])
             
       
def hae_tiketit():
    #kysely = "SELECT * FROM tiketit"
    kysely = "SELECT tiketit.*, tyontekijat.nimi, ratkaisut.ratkaisu, status.status FROM tiketit INNER JOIN tyontekijat ON tiketit.tyontekijaID = tyontekijat.tyontekijaID INNER JOIN status ON tiketit.statusID = status.statusID INNER JOIN ratkaisut ON tiketit.ratkaisuID = ratkaisut.ratkaisuID"
    with closing(muntk.cursor(dictionary=True)) as cursor:
        cursor.execute(kysely)
        tulokset = cursor.fetchall()
        
    tiketit = []
    for rivi in tulokset:
        tiketit.append(luo_tiketti(rivi))
    return tiketit

def lisaa_tiketti(tiketti):
    kysely = "INSERT INTO tiketit (statusID, ratkaisuID, tyontekijaID, asia, asiakasnimi, asiakassposti, kirjauspaiva) VALUES (%s, %s, %s, %s, %s, %s, NOW())"
    with closing(muntk.cursor()) as cursor:
        cursor.execute(kysely, (tiketti.statusID, tiketti.ratkaisuID, tiketti.tyontekijaID, tiketti.asia, tiketti.asiakasnimi, tiketti.asiakassposti))
        muntk.commit()
        
def paivita_tiketti(tikettiID, statusID):
    kysely = "UPDATE tiketit SET statusID = %s WHERE tikettiID = %s"
    with closing(muntk.cursor()) as cursor:
        cursor.execute(kysely, (statusID, tikettiID))
        muntk.commit()
        
def katso_asiaa(tikettiID):
    kysely = "SELECT * FROM tiketit INNER JOIN tyontekijat ON tiketit.tyontekijaID = tyontekijat.tyontekijaID INNER JOIN status ON tiketit.statusID = status.statusID INNER JOIN ratkaisut ON tiketit.ratkaisuID = ratkaisut.ratkaisuID WHERE tikettiID = %s"
    with closing(muntk.cursor(dictionary=True)) as cursor:
        cursor.execute(kysely, (tikettiID,))
        tulokset = cursor.fetchone()
            
    tiketti = luo_tiketti(tulokset)
    return tiketti

def hae_tyontekijat():
    kysely = "SELECT tyontekijat.*, roolit.rooli FROM tyontekijat INNER JOIN roolit ON tyontekijat.rooliID = roolit.rooliID"
    with closing(muntk.cursor(dictionary=True)) as cursor:
        cursor.execute(kysely)
        tulokset = cursor.fetchall()
        
    tyontekijat = []
    for rivi in tulokset:
        tyontekijat.append(luo_tyontekija(rivi))
    return tyontekijat
            
    

def login(tunnus, salasana):
    kysely = "SELECT COUNT(*) FROM tyontekijat WHERE tunnus=%s AND salasana=%s"
    with closing(muntk.cursor()) as cursor:
        cursor.execute(kysely, (tunnus, salasana))
        tulos = cursor.fetchone()
    
    if tulos[0] > 0:
        return True
    else:
        return False
        
    
    
        
# def katso_asia(tikettiID):
#     kysely = "SELECT tiketit.*, tiketit.tikettiID, tiketit.asia FROM tiketit WHERE tikettiID = %s"
#     with closing(muntk.cursor(dictionary=True)) as cursor:
#         cursor.execute(kysely, (tikettiID,))
#         tulokset = cursor.fetchone()
            
#     tiketti = katso_asia(tulokset)
#     return tiketti
        
# def yksi_tiketti(tikettiID):
#     kysely = "SELECT * FROM tiketit WHERE tikettiID = %s"
#     with closing(muntk.cursor(dictionary=True)) as cursor:
#         cursor.execute(kysely, (tikettiID,))
#         tulokset = cursor.fetchone()
            
#     tyontekija = luo_tiketti(tulokset)
#     return tyontekija
        
